import pickle
import pandas as pd
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import UserCreationForm
from django.shortcuts import render, redirect
from textblob import TextBlob
import random
from django.contrib import messages
from datetime import datetime
from .models import HealthStats, Symptom, DiseasePrediction, ChatMessage, Appointment, PatientProfile, Medication, LabResult
from django.conf import settings
import stripe
from django.http import HttpResponse
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from io import BytesIO

stripe.api_key = settings.STRIPE_SECRET_KEY

# Lab Results Data (Mock Database for reference, but we'll use LabResult model)
TESTS = [
    {"id": "1", "name": "Blood Sugar", "normal_range": "70-140"},
    {"id": "2", "name": "Cholesterol", "normal_range": "120-200"},
    {"id": "3", "name": "Hemoglobin", "normal_range": "12-16"},
    {"id": "4", "name": "Triglycerides", "normal_range": "50-150"},
    {"id": "5", "name": "Blood Pressure (Systolic)", "normal_range": "90-120"},
    {"id": "6", "name": "Blood Pressure (Diastolic)", "normal_range": "60-80"},
    {"id": "7", "name": "Liver Function (ALT)", "normal_range": "7-56"},
    {"id": "8", "name": "Liver Function (AST)", "normal_range": "10-40"},
    {"id": "9", "name": "Kidney Function (Creatinine)", "normal_range": "0.6-1.2"},
    {"id": "10", "name": "Thyroid (TSH)", "normal_range": "0.4-4.0"},
    {"id": "11", "name": "Vitamin D", "normal_range": "20-50"},
    {"id": "12", "name": "Vitamin B12", "normal_range": "200-900"},
    {"id": "13", "name": "Iron Levels", "normal_range": "60-170"},
    {"id": "14", "name": "Calcium", "normal_range": "8.5-10.2"},
    {"id": "15", "name": "Sodium", "normal_range": "135-145"},
    {"id": "16", "name": "Potassium", "normal_range": "3.5-5.0"},
    {"id": "17", "name": "Uric Acid", "normal_range": "3.4-7.0"},
    {"id": "18", "name": "ESR", "normal_range": "0-20"},
    {"id": "19", "name": "CRP", "normal_range": "0-10"},
    {"id": "20", "name": "HbA1c", "normal_range": "4-6"}
]

# Helper function to fetch lab results
def get_tests_with_results(user):
    tests_with_results = []
    for test in TESTS:
        test_copy = test.copy()
        results = LabResult.objects.filter(user=user, test_name=test['name']).order_by('date')
        test_copy['results'] = [{'value': result.value, 'date': result.date.strftime('%Y-%m-%d')} for result in results]
        tests_with_results.append(test_copy)
    return tests_with_results

# Home View
def home(request):
    return render(request, 'healthcare/home.html', {'title': 'MediSync'})

# Generate unique patient_id
def generate_patient_id():
    while True:
        patient_id = f"PAT{random.randint(1000000, 9999999)}"
        if not PatientProfile.objects.filter(patient_id=patient_id).exists():
            return patient_id

# Register View
def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            # Create PatientProfile with extra fields
            age = request.POST.get('age')
            gender = request.POST.get('gender')
            blood_group = request.POST.get('blood_group')
            address = request.POST.get('address')
            emergency_contact = request.POST.get('emergency_contact')
            patient_id = generate_patient_id()
            
            PatientProfile.objects.create(
                user=user,
                patient_id=patient_id,
                age=age,
                gender=gender,
                blood_group=blood_group,
                address=address,
                emergency_contact=emergency_contact
            )
            
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=password)
            login(request, user)
            messages.success(request, "Registration successful! Welcome to MediSync.")
            return redirect('dashboard')
    else:
        form = UserCreationForm()
    return render(request, 'healthcare/register.html', {'form': form, 'title': 'Register'})

# Login View
def user_login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            messages.success(request, "Login successful!")
            return redirect('dashboard')  # Redirect to dashboard after login
        else:
            messages.error(request, "Invalid credentials. Please try again.")
            return render(request, 'healthcare/login.html', {'title': 'Login'})
    return render(request, 'healthcare/login.html', {'title': 'Login'})

# Logout View
def user_logout(request):
    logout(request)
    messages.success(request, "Logged out successfully!")
    return redirect('home')

# Dashboard View
@login_required
def dashboard(request):
    # Fetch recent appointments from Appointment model
    recent_appointments = Appointment.objects.filter(user=request.user).order_by('-appointment_datetime')[:5]
    
    # Fetch lab results using helper function
    tests_with_results = get_tests_with_results(request.user)
    
    # Fetch recent disease predictions
    recent_predictions = DiseasePrediction.objects.filter(user=request.user).order_by('-predicted_at')[:5]
    
    return render(request, 'healthcare/dashboard.html', {
        'tests': tests_with_results,
        'recent_appointments': recent_appointments,
        'recent_predictions': recent_predictions
    })

# Patient ID Card View
@login_required
def patient_id_card(request):
    try:
        profile = PatientProfile.objects.get(user=request.user)
    except PatientProfile.DoesNotExist:
        # Create a PatientProfile if it doesn't exist
        patient_id = generate_patient_id()
        profile = PatientProfile.objects.create(
            user=request.user,
            patient_id=patient_id
        )
    return render(request, 'healthcare/patient_id_card.html', {'profile': profile, 'title': 'Patient ID Card'})

# Health Stats Input View
@login_required
def health_stats_input(request):
    if request.method == 'POST':
        blood_sugar = request.POST.get('blood_sugar')
        cholesterol = request.POST.get('cholesterol')
        hemoglobin = request.POST.get('hemoglobin')
        
        HealthStats.objects.create(
            user=request.user,
            blood_sugar=float(blood_sugar) if blood_sugar else None,
            cholesterol=float(cholesterol) if cholesterol else None,
            hemoglobin=float(hemoglobin) if hemoglobin else None
        )
        messages.success(request, "Health stats saved successfully!")
        return redirect('dashboard')
    
    return render(request, 'healthcare/health_stats_input.html', {'title': 'Add Health Stats'})

# Health Stats View
@login_required
def health_stats(request):
    # Fetch lab results using helper function
    tests_with_results = get_tests_with_results(request.user)
    
    return render(request, 'healthcare/health_stats.html', {'tests': tests_with_results})

def normalize(symptom_name):
    return symptom_name.lower().replace(' ', '_')

# Disease Prediction View
@login_required
def disease_prediction(request):
    symptoms = Symptom.objects.all().order_by('name')
    print("Symptoms in view:", [s.name for s in symptoms])
    if request.method == 'POST':
        selected_symptoms = request.POST.getlist('symptoms')
        input_data = {col: 0 for col in settings.SYMPTOM_COLUMNS}
        try:
            print("Selected Symptoms (IDs):", selected_symptoms)
            for symptom_id in selected_symptoms:
                symptom = Symptom.objects.get(id=symptom_id)
                symptom_key = normalize(symptom.name)
                print(f"Symptom ID: {symptom_id}, Symptom Name: {symptom_key}")
                if symptom_key in input_data:
                    input_data[symptom_key] = 1
                else:
                    print(f"Warning: {symptom_key} not in symptom_columns")
            print("Input Data:", input_data)
            input_df = pd.DataFrame([input_data], columns=settings.SYMPTOM_COLUMNS)
            print("Input DataFrame:", input_df)
            if settings.DISEASE_MODEL is None:
                messages.error(request, "Model not loaded. Please contact the administrator.")
                return redirect('disease_prediction')
            prediction = settings.DISEASE_MODEL.predict(input_df)[0]
            print("Prediction:", prediction)
            disease_prediction = DiseasePrediction.objects.create(user=request.user, prediction=prediction)
            disease_prediction.symptoms.set(selected_symptoms)
            messages.success(request, f"Prediction: {prediction}. Saved to your dashboard.")
            return redirect('dashboard')
        except Symptom.DoesNotExist:
            messages.error(request, "One or more selected symptoms are invalid. Please try again.")
            return redirect('disease_prediction')
    return render(request, 'healthcare/disease_prediction.html', {'symptoms': symptoms, 'title': 'Disease Prediction'})

# AI Chatbot View
@login_required
def chat_with_ai_bot(request):
    if request.method == 'POST':
        user_message = request.POST.get('message', '').strip()
        if user_message:
            # Sentiment analysis
            blob = TextBlob(user_message)
            sentiment = blob.sentiment.polarity
            recent_messages = ChatMessage.objects.filter(user=request.user).order_by('-timestamp')[:5]
            context = [msg.message.lower() for msg in recent_messages]
            latest_stats = HealthStats.objects.filter(user=request.user).order_by('-date').first()
            lab_results = get_tests_with_results(request.user)

            # Default response based on sentiment
            response = "I'm here to assist you with your medical queries! What’s on your mind? 😊"
            if sentiment < -0.3:
                response = "I’m really sorry to hear you’re feeling this way. Let’s figure out how I can help. 😔"
            elif sentiment > 0.3:
                response = "It’s great to hear you’re feeling positive! How can I assist you today? 😊"

            # Convert user message to lowercase for keyword matching
            user_message_lower = user_message.lower()

            # Define keyword categories
            symptom_keywords = ["fever", "cough", "headache", "pain", "tired", "nausea", "cold", "sore throat", "stomach ache", "fatigue", "dizziness", "rash", "diarrhea", "vomiting", "joint pain", "back pain"]
            health_stat_keywords = ["blood sugar", "cholesterol", "hemoglobin", "blood pressure", "thyroid", "vitamin d", "iron"]
            emergency_keywords = ["chest pain", "difficulty breathing", "severe"]
            medisync_feature_keywords = ["appointment", "medication", "lab results", "disease prediction", "health stats", "bmi", "emergency", "help"]
            general_keywords = ["diet", "sleep", "exercise", "stress", "side effects", "missed dose", "hello", "hi", "what can you do", "not feeling well"]

            # Check for keywords and respond accordingly
            # 1. Emergency Situations
            if any(keyword in user_message_lower for keyword in emergency_keywords):
                response = "This sounds serious! 🚨 Please seek immediate medical attention or call emergency services. You can also check the Emergency Services section on MediSync for quick contacts."

            # 2. MediSync Features
            elif any(keyword in user_message_lower for keyword in medisync_feature_keywords):
                if "appointment" in user_message_lower:
                    response = "To book an appointment, go to the 'Book Appointment' section on MediSync, select your specialty, doctor, and preferred time. You'll need to make a payment to confirm the booking."
                elif "medication" in user_message_lower:
                    response = "You can track your medications in the 'Medication Tracker' section on MediSync. Add the medication name, dosage, time, and days to set reminders."
                elif "lab results" in user_message_lower:
                    response = "You can view or add your lab results in the 'Lab Results' section on MediSync. Would you like to know about a specific test result?"
                elif "disease prediction" in user_message_lower:
                    response = "I can help with that! Go to the 'Disease Prediction' section on MediSync, select your symptoms, and I'll predict possible conditions for you. Alternatively, tell me your symptoms, and I can guide you!"
                elif "health stats" in user_message_lower:
                    response = "You can add your health stats like blood sugar, cholesterol, and hemoglobin in the 'Add Health Stats' section on MediSync. Want to check your latest stats?"
                elif "bmi" in user_message_lower:
                    response = "You can calculate your BMI in the 'BMI Calculator' section on MediSync. Enter your height and weight, and I'll tell you your BMI category!"
                elif "emergency" in user_message_lower:
                    response = "For emergencies, check the 'Emergency Services' section on MediSync. It has quick contact numbers like the National Emergency Number (112) and Ambulance Service (108)."
                elif "help" in user_message_lower:
                    response = "Need help with MediSync? Visit the 'Help' section for FAQs and guidance on using all features, from tracking health stats to booking appointments."

            # 3. Symptoms
            elif any(keyword in user_message_lower for keyword in symptom_keywords):
                symptoms_mentioned = [keyword for keyword in symptom_keywords if keyword in user_message_lower]
                if "fever" in symptoms_mentioned:
                    response = "A fever can be due to infections like the flu. Stay hydrated, rest, and monitor your temperature. If it exceeds 103°F or lasts more than 3 days, consult a doctor."
                elif "headache" in symptoms_mentioned:
                    response = "Headaches can be caused by stress or dehydration. Try drinking water, resting, or taking a pain reliever. If it’s severe or persistent, consult a doctor."
                elif "cold" in symptoms_mentioned:
                    response = "A cold often includes symptoms like a runny nose or cough. Rest, stay hydrated, and consider over-the-counter remedies. If symptoms worsen, see a doctor."
                elif "sore throat" in symptoms_mentioned:
                    response = "A sore throat might be due to a viral infection or strain. Gargle with warm salt water and stay hydrated. If it lasts more than a few days, consult a doctor."
                elif "stomach ache" in symptoms_mentioned:
                    response = "A stomach ache could be due to indigestion or something you ate. Try eating light, avoid spicy foods, and rest. If it’s severe or persistent, see a doctor."
                elif "fatigue" in symptoms_mentioned or "tired" in symptoms_mentioned:
                    response = "Feeling fatigued can be due to lack of sleep, stress, or low energy. Ensure you’re getting 7-8 hours of sleep and eating a balanced diet. If it continues, consult a doctor."
                elif "dizziness" in symptoms_mentioned:
                    response = "Dizziness might be due to dehydration or low blood pressure. Sit down, hydrate, and avoid sudden movements. If it persists, seek medical advice."
                elif "rash" in symptoms_mentioned:
                    response = "A rash could be an allergic reaction or skin irritation. Avoid scratching, use a mild cream, and keep the area clean. If it spreads or worsens, see a doctor."
                elif "diarrhea" in symptoms_mentioned:
                    response = "Diarrhea can lead to dehydration. Drink plenty of fluids, avoid heavy foods, and consider oral rehydration solutions. If it lasts more than 2 days, consult a doctor."
                elif "vomiting" in symptoms_mentioned:
                    response = "Vomiting might be due to food poisoning or a virus. Stay hydrated with small sips of water and avoid solid food for a while. If it persists, see a doctor."
                elif "joint pain" in symptoms_mentioned:
                    response = "Joint pain can be due to overexertion or inflammation. Rest the joint, apply a warm compress, and avoid strain. If it’s severe or ongoing, consult a doctor."
                elif "back pain" in symptoms_mentioned:
                    response = "Back pain might be due to poor posture or strain. Try stretching, maintain good posture, and avoid heavy lifting. If it’s severe, see a doctor."
                else:
                    response = f"I see you mentioned {', '.join(symptoms_mentioned)}. Can you tell me more, or would you like to use the Disease Prediction feature on MediSync?"

            # 4. Health Stats and Lab Results
            elif any(keyword in user_message_lower for keyword in health_stat_keywords):
                if latest_stats:
                    response = "Let’s check your latest health stats...\n"
                    if "blood sugar" in user_message_lower and latest_stats.blood_sugar:
                        response += f"Your latest blood sugar is {latest_stats.blood_sugar} mg/dL. "
                        if latest_stats.blood_sugar > 200:
                            response += "That’s quite high—please consult a doctor."
                        else:
                            response += "Looks like it’s in a normal range."
                    if "cholesterol" in user_message_lower and latest_stats.cholesterol:
                        response += f"Your latest cholesterol is {latest_stats.cholesterol} mg/dL. "
                        if latest_stats.cholesterol > 200:
                            response += "That’s a bit high—consider consulting a doctor."
                        else:
                            response += "It’s within a normal range."
                    if "hemoglobin" in user_message_lower and latest_stats.hemoglobin:
                        response += f"Your latest hemoglobin is {latest_stats.hemoglobin} g/dL. "
                        if latest_stats.hemoglobin < 12:
                            response += "That’s low—please consult a doctor."
                        else:
                            response += "Looks good!"
                else:
                    response = "I don’t have your health stats yet. Please add some in the 'Add Health Stats' section on MediSync."

                # Check lab results for additional stats
                if "blood pressure" in user_message_lower:
                    bp_systolic = next((test for test in lab_results if test['name'] == "Blood Pressure (Systolic)"), None)
                    bp_diastolic = next((test for test in lab_results if test['name'] == "Blood Pressure (Diastolic)"), None)
                    if bp_systolic['results'] and bp_diastolic['results']:
                        latest_systolic = bp_systolic['results'][-1]['value']
                        latest_diastolic = bp_diastolic['results'][-1]['value']
                        response += f"\nYour latest blood pressure is {latest_systolic}/{latest_diastolic} mmHg. "
                        if latest_systolic > 120 or latest_diastolic > 80:
                            response += "That’s higher than normal—please consult a doctor."
                        else:
                            response += "Looks normal!"
                elif "thyroid" in user_message_lower:
                    thyroid = next((test for test in lab_results if test['name'] == "Thyroid (TSH)"), None)
                    if thyroid['results']:
                        latest_tsh = thyroid['results'][-1]['value']
                        response += f"\nYour latest TSH level is {latest_tsh} mIU/L. "
                        if latest_tsh < 0.4 or latest_tsh > 4.0:
                            response += "That’s outside the normal range—please consult a doctor."
                        else:
                            response += "Looks normal!"
                elif "vitamin d" in user_message_lower:
                    vitamin_d = next((test for test in lab_results if test['name'] == "Vitamin D"), None)
                    if vitamin_d['results']:
                        latest_vitamin_d = vitamin_d['results'][-1]['value']
                        response += f"\nYour latest Vitamin D level is {latest_vitamin_d} ng/mL. "
                        if latest_vitamin_d < 20:
                            response += "That’s low—you might need a supplement. Consult a doctor."
                        else:
                            response += "Looks good!"
                elif "iron" in user_message_lower:
                    iron = next((test for test in lab_results if test['name'] == "Iron Levels"), None)
                    if iron['results']:
                        latest_iron = iron['results'][-1]['value']
                        response += f"\nYour latest iron level is {latest_iron} mcg/dL. "
                        if latest_iron < 60:
                            response += "That’s low—please consult a doctor."
                        else:
                            response += "Looks normal!"

            # 5. General Medical and MediSync Queries
            elif any(keyword in user_message_lower for keyword in general_keywords):
                if "diet" in user_message_lower:
                    response = "A balanced diet is key! Include plenty of fruits, vegetables, whole grains, and lean proteins. Avoid processed foods and sugary drinks. Need more personalized advice? Consult a doctor via MediSync."
                elif "sleep" in user_message_lower:
                    response = "Aim for 7-8 hours of sleep per night. Create a relaxing bedtime routine, avoid screens before bed, and keep your sleep schedule consistent. Struggling with sleep? Talk to a doctor."
                elif "exercise" in user_message_lower:
                    response = "Regular exercise is great for your health! Aim for at least 30 minutes of moderate activity, like walking or yoga, most days of the week. Check with a doctor if you have any concerns."
                elif "stress" in user_message_lower:
                    response = "Stress can affect your health. Try relaxation techniques like deep breathing, meditation, or a hobby you enjoy. If it’s overwhelming, consider speaking to a professional through MediSync."
                elif "side effects" in user_message_lower:
                    response = "Medication side effects can vary. Common ones include nausea or dizziness. Check your medication details in the 'Medication Tracker' on MediSync, and consult a doctor if you’re concerned."
                elif "missed dose" in user_message_lower:
                    response = "If you missed a dose, take it as soon as you remember unless it’s close to your next dose—then skip it. Don’t double up! Check your schedule in the 'Medication Tracker' on MediSync."
                elif "hello" in user_message_lower or "hi" in user_message_lower:
                    response = "Hello! I’m MediSync’s AI chatbot, here to help with your medical queries and guide you through the app. What’s on your mind? 😊"
                elif "what can you do" in user_message_lower:
                    response = "I can help with a lot! Ask me about symptoms, health stats, lab results, or how to use MediSync features like booking appointments, tracking medications, or predicting diseases. What would you like to know?"
                elif "not feeling well" in user_message_lower:
                    response = "I’m sorry to hear that. 😔 Can you tell me more about how you’re feeling? For example, do you have any specific symptoms like fever or fatigue? You can also use the Disease Prediction feature on MediSync."

            # 6. Fallback Response
            else:
                response = "I’m here to help with your medical queries. Can you tell me more about your symptoms, health concerns, or how to use MediSync features?"

            # Save the conversation
            ChatMessage.objects.create(user=request.user, message=user_message, response=response)

    messages = ChatMessage.objects.filter(user=request.user).order_by('timestamp')
    return render(request, 'healthcare/chat-ai.html', {'messages': messages, 'title': 'Chat with AI Bot'})

# Appointment Scheduling View
@login_required
def book_appointment(request):
    if request.method == 'POST':
        specialization = request.POST.get('specialization')
        doctor = request.POST.get('doctor')
        datetime_str = request.POST.get('datetime')
        try:
            # Convert datetime string to datetime object
            appointment_datetime = datetime.strptime(datetime_str, '%Y-%m-%dT%H:%M')

            # Create a PaymentIntent on form submission
            payment_intent = stripe.PaymentIntent.create(
                amount=5000,  # $50 in cents
                currency='usd',
                description=f"Appointment with {doctor}",
                metadata={'user_id': request.user.id},
            )

            # Save appointment to database (status pending until payment confirmation)
            appointment = Appointment.objects.create(
                user=request.user,
                specialty=specialization,
                doctor=doctor,
                appointment_datetime=appointment_datetime,
                status='Pending'  # Status will be updated after payment
            )

            # Pass the client secret and appointment ID to the template for payment confirmation
            return render(request, 'healthcare/book_appointment.html', {
                'client_secret': payment_intent['client_secret'],
                'appointment_id': appointment.id,
                'stripe_publishable_key': settings.STRIPE_PUBLISHABLE_KEY,
                'specialization': specialization,
                'doctor': doctor,
                'datetime': datetime_str,
            })

        except ValueError:
            messages.error(request, "Invalid date format. Please try again.")
            return redirect('book_appointment')
        except stripe.error.StripeError as e:
            messages.error(request, f"Payment setup failed: {str(e)}")
            return redirect('book_appointment')

    return render(request, 'healthcare/book_appointment.html', {
        'stripe_publishable_key': settings.STRIPE_PUBLISHABLE_KEY
    })

# View to confirm payment and update appointment status
@login_required
def confirm_payment(request):
    if request.method == 'POST':
        appointment_id = request.POST.get('appointment_id')
        try:
            appointment = Appointment.objects.get(id=appointment_id, user=request.user)
            # Update appointment status to Confirmed
            appointment.status = 'Confirmed'
            appointment.save()
            messages.success(request, f"Appointment booked with {appointment.doctor} for {appointment.specialty} on {appointment.appointment_datetime}! Payment successful.")
            return redirect('dashboard')
        except Appointment.DoesNotExist:
            messages.error(request, "Invalid appointment ID.")
            return redirect('book_appointment')
        except stripe.error.StripeError as e:
            messages.error(request, f"Payment confirmation failed: {str(e)}")
            return redirect('book_appointment')

# BMI Calculator View
@login_required
def bmi_calculator(request):
    if request.method == 'POST':
        try:
            height = float(request.POST.get('height')) / 100  # Convert cm to meters
            weight = float(request.POST.get('weight'))
            
            bmi = weight / (height * height)
            if bmi < 18.5:
                category = "Underweight"
            elif 18.5 <= bmi < 25:
                category = "Normal"
            elif 25 <= bmi < 30:
                category = "Overweight"
            else:
                category = "Obese"
            
            return render(request, 'healthcare/bmi_calculator.html', {'bmi': bmi, 'category': category})
        except (ValueError, TypeError):
            messages.error(request, "Invalid height or weight. Please enter valid numbers.")
            return redirect('bmi_calculator')
    
    return render(request, 'healthcare/bmi_calculator.html')

# Medication Tracking View
@login_required
def medication_tracker(request):
    if request.method == 'POST':
        name = request.POST['name']
        dosage = request.POST['dosage']
        time_str = request.POST['time']
        days = request.POST['days']
        try:
            # Convert time string to TimeField format
            time_obj = datetime.strptime(time_str, '%H:%M').time()
            Medication.objects.create(
                user=request.user,
                name=name,
                dosage=dosage,
                time=time_obj,
                days=days
            )
            messages.success(request, "Medication added successfully!")
            return redirect('dashboard')
        except ValueError:
            messages.error(request, "Invalid time format. Please use HH:MM (e.g., 14:30).")
            return redirect('medication_tracker')
    medications = Medication.objects.filter(user=request.user)
    return render(request, 'healthcare/medication_tracker.html', {'medications': medications, 'title': 'Medication Tracker'})

# Lab Results View
@login_required
def lab_results(request):
    if request.method == 'POST':
        for test in TESTS:
            test_id = test['id']
            result = request.POST.get(f'result_{test_id}')
            date_str = request.POST.get(f'date_{test_id}')
            
            if result and date_str:
                try:
                    # Convert date string to date object
                    result_date = datetime.strptime(date_str, '%Y-%m-%d').date()
                    # Save to LabResult model
                    LabResult.objects.create(
                        user=request.user,
                        test_name=test['name'],
                        value=float(result),
                        date=result_date
                    )
                except ValueError:
                    messages.error(request, f"Invalid date or value for {test['name']}. Please try again.")
                    return redirect('lab_results')
        
        messages.success(request, "Lab results saved successfully!")
        return redirect('lab_results')
    
    # Fetch lab results using helper function
    tests_with_results = get_tests_with_results(request.user)
    
    return render(request, 'healthcare/lab_results.html', {'tests': tests_with_results})

# Emergency Services View
@login_required
def emergency_services(request):
    emergency_contacts = [
        {'name': 'National Emergency Number', 'number': '112'},
        {'name': 'Ambulance Service', 'number': '108'},
    ]
    return render(request, 'healthcare/emergency_services.html', {'emergency_contacts': emergency_contacts, 'title': 'Emergency Services'})

# Help View
@login_required
def help_page(request):
    faqs = [
        {'question': 'How do I track my health stats?', 'answer': 'Go to the Health Stats section, enter your details, and save them.'},
        {'question': 'How can I book an appointment?', 'answer': 'Visit the Book Appointment section, fill in the details, and submit.'},
        {'question': 'What should I do in an emergency?', 'answer': 'Check the Emergency Services section for quick contact numbers.'},
        {'question': 'How can I predict diseases using MediSync?', 'answer': 'Navigate to the Disease Prediction section, input your symptoms, and let our AI model (85% accuracy) analyze the data.'},
        {'question': 'How do I chat with the MediSync Bot?', 'answer': 'Go to the Chat with MediSync Bot section, type your query, and the AI will respond with helpful advice.'},
        {'question': 'How can I view and download my lab results?', 'answer': 'Visit the Lab Results section to view your results, and use the Manage Reports section to download them as a PDF.'},
        {'question': 'How do I calculate my BMI?', 'answer': 'Go to the BMI Calculator section, enter your height and weight, and the system will calculate your BMI instantly.'},
        {'question': 'Is my data secure with MediSync?', 'answer': 'Yes, MediSync uses AES-256 encryption and follows HIPAA-compliant practices to ensure your data is secure and private.'},
        {'question': 'How can I update my profile information?', 'answer': 'You can update your details like age, gender, and address by visiting your Patient ID Card section and editing your profile.'},
        {'question': 'What should I do if I forget my password?', 'answer': 'Click on the "Forgot Password" link on the login page, enter your email, and follow the instructions to reset your password.'},
    ]
    return render(request, 'healthcare/help.html', {'faqs': faqs, 'title': 'Help'})

# Manage Reports View
@login_required
def manage_reports(request):
    # Fetch all lab results for the user
    lab_results = LabResult.objects.filter(user=request.user).order_by('date')

    # Group results by date
    reports_by_date = {}
    for result in lab_results:
        date_str = result.date.strftime('%Y-%m-%d')
        if date_str not in reports_by_date:
            reports_by_date[date_str] = []
        # Add normal range for display
        normal_range = next((test['normal_range'] for test in TESTS if test['name'] == result.test_name), "Unknown")
        result.normal_range = normal_range
        reports_by_date[date_str].append(result)

    if request.method == 'POST':
        action = request.POST.get('action')
        date_str = request.POST.get('date')

        try:
            date_obj = datetime.strptime(date_str, '%Y-%m-%d').date()
        except ValueError:
            messages.error(request, "Invalid date format.")
            return redirect('manage_reports')

        if action == 'delete':
            # Delete all lab results for the given date
            LabResult.objects.filter(user=request.user, date=date_obj).delete()
            messages.success(request, f"Lab results for {date_str} deleted successfully!")
            return redirect('manage_reports')

        elif action == 'download':
            # Fetch lab results for the given date
            results = LabResult.objects.filter(user=request.user, date=date_obj)
            if not results:
                messages.error(request, "No results found for the selected date.")
                return redirect('manage_reports')

            # Filter out null values and prepare data for PDF
            pdf_data = []
            for result in results:
                if result.value is not None:  # Only include non-null values
                    normal_range = next((test['normal_range'] for test in TESTS if test['name'] == result.test_name), "Unknown")
                    pdf_data.append([result.test_name, str(result.value), normal_range])

            if not pdf_data:
                messages.error(request, "No non-null results found for the selected date to download.")
                return redirect('manage_reports')

            # Create a PDF using ReportLab
            buffer = BytesIO()
            doc = SimpleDocTemplate(buffer, pagesize=A4)
            elements = []

            # Styles
            styles = getSampleStyleSheet()
            # Custom styles for better formatting
            styles.add(ParagraphStyle(name='HeaderStyle', fontSize=16, alignment=1, spaceAfter=12, fontName='Helvetica-Bold'))
            styles.add(ParagraphStyle(name='TitleStyle', fontSize=14, alignment=1, spaceAfter=12, fontName='Helvetica-Bold'))
            styles.add(ParagraphStyle(name='DetailStyle', fontSize=12, alignment=0, spaceAfter=6))
            styles.add(ParagraphStyle(name='FooterStyle', fontSize=10, alignment=1, spaceBefore=12, textColor=colors.grey, fontName='Helvetica-Oblique'))

            # Header: MediSync Solutions
            header = Paragraph("MediSync Solutions", styles['HeaderStyle'])
            elements.append(header)
            elements.append(Spacer(1, 12))

            # Title: Lab Results
            title = Paragraph("Lab Results", styles['TitleStyle'])
            elements.append(title)
            elements.append(Spacer(1, 24))

            # Patient Details
            patient_name = Paragraph(f"Patient Name: {request.user.username}", styles['DetailStyle'])
            test_date = Paragraph(f"Date of Tests: {date_str}", styles['DetailStyle'])
            # Fetch gender from PatientProfile (assuming it exists in your model)
            gender = getattr(request.user, 'patientprofile', None).gender if hasattr(request.user, 'patientprofile') else "Not Set"
            patient_gender = Paragraph(f"Gender: {gender}", styles['DetailStyle'])

            elements.append(patient_name)
            elements.append(test_date)
            elements.append(patient_gender)
            elements.append(Spacer(1, 24))

            # Results Table
            table_data = [["Test Name", "Result", "Normal Range"]] + pdf_data
            table = Table(table_data)

            # Table styling
            table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1E1B4B')),  # Header background (dark blue)
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),  # Header text color
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 12),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                ('BACKGROUND', (0, 1), (-1, -1), colors.HexColor('#E5E7EB')),  # Row background (light gray)
                ('TEXTCOLOR', (0, 1), (-1, -1), colors.black),
                ('GRID', (0, 0), (-1, -1), 1, colors.black),
                ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.HexColor('#E5E7EB'), colors.white]),  # Alternating row colors
            ]))

            elements.append(table)
            elements.append(Spacer(1, 48))

            # Footer
            footer = Paragraph("This Report is based on Self-defined Results | Not for Medico Legal Purpose", styles['FooterStyle'])
            elements.append(footer)

            # Build the PDF
            doc.build(elements)

            # Get the PDF content
            pdf_content = buffer.getvalue()
            buffer.close()

            # Create HTTP response with the PDF
            response = HttpResponse(content_type='application/pdf')
            response['Content-Disposition'] = f'attachment; filename="lab_report_{date_str}.pdf"'
            response.write(pdf_content)
            return response

    return render(request, 'healthcare/manage_reports.html', {
        'reports_by_date': reports_by_date,
        'title': 'Manage Reports'
    })