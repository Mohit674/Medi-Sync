from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('register/', views.register, name='register'),
    path('login/', views.user_login, name='login'),
    path('logout/', views.user_logout, name='logout'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('patient-id-card/', views.patient_id_card, name='patient_id_card'),
    path('health-stats-input/', views.health_stats_input, name='health_stats_input'),
    path('health-stats/', views.health_stats, name='health_stats'),
    path('disease-prediction/', views.disease_prediction, name='disease_prediction'),
    path('chat-ai/', views.chat_with_ai_bot, name='chat_ai'),
    path('book-appointment/', views.book_appointment, name='book_appointment'),
    path('bmi-calculator/', views.bmi_calculator, name='bmi_calculator'),
    path('medication-tracker/', views.medication_tracker, name='medication_tracker'),
    path('lab-results/', views.lab_results, name='lab_results'),
    path('emergency-services/', views.emergency_services, name='emergency_services'),
    path('help/', views.help_page, name='help'),
    path('confirm-payment/', views.confirm_payment, name='confirm_payment'),
    path('manage-reports/', views.manage_reports, name='manage_reports'),
]