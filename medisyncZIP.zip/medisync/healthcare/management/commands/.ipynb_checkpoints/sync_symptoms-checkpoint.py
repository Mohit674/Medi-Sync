from django.core.management.base import BaseCommand
from django.conf import settings
from healthcare.models import Symptom

class Command(BaseCommand):
    help = 'Syncs symptoms from symptom_columns.pkl into the database'

    def handle(self, *args, **kwargs):
        if not hasattr(settings, 'SYMPTOM_COLUMNS') or settings.SYMPTOM_COLUMNS is None:
            self.stdout.write(self.style.ERROR('SYMPTOM_COLUMNS not found in settings. Please ensure the model is trained and symptom_columns.pkl exists.'))
            return

        symptom_columns = settings.SYMPTOM_COLUMNS
        existing_symptoms = set(Symptom.objects.values_list('name', flat=True))
        symptom_columns_formatted = [s.replace('_', ' ').title() for s in symptom_columns]

        for symptom_name in symptom_columns_formatted:
            if symptom_name.lower() not in [es.lower() for es in existing_symptoms]:
                Symptom.objects.get_or_create(name=symptom_name)
                self.stdout.write(self.style.SUCCESS(f'Added symptom: {symptom_name}'))
            else:
                self.stdout.write(f'Symptom already exists: {symptom_name}')

        self.stdout.write(self.style.SUCCESS('Symptom sync completed!'))