import pickle

with open('disease_model.pkl', 'rb') as f:
    model = pickle.load(f)

with open('symptom_columns.pkl', 'rb') as f:
    symptom_columns = pickle.load(f)
# Selected Symptom objects from DB
selected_symptoms = symptom.objects.filter(id__in=request.POST.getlist('symptoms'))

# Convert symptom names to same format used in training
user_symptoms = [s.name.strip().lower().replace(" ", "_") for s in selected_symptoms]
