import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import pickle

# Load the training dataset
data = pd.read_csv('disease_train.csv', encoding='latin1')

# Features (symptoms) and target (disease)
X = data.drop('disease', axis=1)
y = data['disease']

# Split the dataset into training and validation sets
X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

# Train the Random Forest model
model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# Validate the model
y_pred = model.predict(X_val)
accuracy = accuracy_score(y_val, y_pred)
print(f"Validation Accuracy: {accuracy * 100:.2f}%")

# Load the test dataset and evaluate
test_data = pd.read_csv('disease_test.csv', encoding='latin1')
X_test = test_data.drop('disease', axis=1)
y_test = test_data['disease']
y_test_pred = model.predict(X_test)
test_accuracy = accuracy_score(y_test, y_test_pred)
print(f"Test Accuracy: {test_accuracy * 100:.2f}%")

# Save the model
with open('disease_model.pkl', 'wb') as f:
    pickle.dump(model, f)

# Save the symptom columns
symptom_columns = X.columns.tolist()
with open('symptom_columns.pkl', 'wb') as f:
    pickle.dump(symptom_columns, f)